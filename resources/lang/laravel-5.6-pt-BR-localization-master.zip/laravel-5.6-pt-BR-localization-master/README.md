# Arquivos de linguagem em Português do Brasil (pt-BR) para Laravel 5.6

## Instalação
1. Download
  ```
  $ cd resources/lang/
  $ git clone https://github.com/lucascudo/laravel-5.6-pt-BR-localization.git ./pt-BR
  ```
2. Configuração
  ```
  // Altere Linha 81 do arquivo config/app.php para:
  'locale' => 'pt-BR',
  ```
